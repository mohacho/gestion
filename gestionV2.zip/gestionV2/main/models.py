from django.db import models
from django.contrib.auth.models import User

    
class Conge(models.Model):
    
    demande_par=models.ForeignKey(User, on_delete=models.CASCADE)
    
    type_conge=models.CharField(max_length=30,null=True)
    
    date_demande=models.DateTimeField(auto_now_add=True)
    
    debut=models.DateField(null=True)
    
    fin=models.DateField(null=True)
    
    emp_message=models.CharField(max_length=400,null=True)
    
    des_adm=models.BooleanField(null=True)
    
    adm_message=models.CharField(max_length=400,null=True)
    


class Document(models.Model):
    
    demande_par=models.ForeignKey(User, on_delete=models.CASCADE)
    
    date_demande=models.DateTimeField(auto_now_add=True)
    
    doc_type=models.CharField(max_length=30)
    
    emp_message=models.CharField(max_length=400,null=True)
    
    adm_message=models.CharField(max_length=400,null=True)
    