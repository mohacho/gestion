from django.shortcuts import render,get_object_or_404,redirect
from django.contrib.auth.models import User
from .models import Conge,Document
from django.contrib.auth.decorators import login_required

@login_required(login_url='/login/')
def home(request):
    user=request.user
    conges=Conge.objects.all()
    docs=Document.objects.all()
   
    if(user.is_staff):
        return render(request,'homeR.html',{'user':user,'conges':conges,'docs':docs})
    else:
        return render(request,'homeI.html',{'user':user,'conges':conges,'docs':docs})
   
@login_required(login_url='/login/')
def mesdemandes(request, pk):
    
    dem = get_object_or_404(Conge , pk=pk)
    demandes=Conge.objects.all()
   
    
    return render(request, 'mesdemandes.html', {'dem': dem ,  'demandes':demandes})

user = User.objects.first()


@login_required(login_url='/login/')
def demanderCong(request):
     user=request.user
     if (request.method=='POST'):
        a = request.POST['conge_s']
        b = request.POST['datedebut']
        c = request.POST['datefin']
        d = request.POST['message']
        conge=Conge.objects.create(
        demande_par = user,
        type_conge = a,
            debut = b,
            fin = c, 
            emp_message = d,
            )
        return render(request,'demandeENR.html',{'conge':conge})
     return render(request, 'demandeCong.html')
    
@login_required(login_url='/login/')
def demanderDoc(request):
    user=request.user
    if (request.method=='POST'):
        e = request.POST['message']
        f = request.POST['docc']
        doc= Document.objects.create(
            
        demande_par=user,
    
        emp_message=e,
      
        doc_type=f,
        )
        return render(request,'demandeENG.html',{'doc':doc})
    return render(request, 'demandeDoc.html')


def traiter(request,pk):
    conges=Conge.objects.get(id=pk)
    if request.method =='POST':
        des=request.POST['des']
        mess=request.POST['message']
        conges.des_adm=des
        conges.adm_message=mess
        conges.save()
        return redirect(traiter,pk=pk)
        
    return render(request,'traitement.html',{'conges':conges})

def traiterdoc(request,pk):
    doc=Document.objects.get(id=pk)
    if request.method =='POST':
        mess=request.POST['message']
        doc.adm_message=mess
        doc.save()
        return redirect(traiterdoc,pk=pk)
    
    return render(request,'traitement2.html',{'doc':doc})